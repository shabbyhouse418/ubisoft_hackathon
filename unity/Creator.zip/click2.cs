﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class click2 : MonoBehaviour
{
    GameManager GM;
    GameObject o_GM;
    bool is_clicked = false;

    void Start()
    {
        o_GM = GameObject.Find("GM");
        GM = o_GM.GetComponent<GameManager>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnMouseDown()
    {
        SceneManager.LoadSceneAsync("SampleScene");
    }
}
