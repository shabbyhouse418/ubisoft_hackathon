﻿using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

struct point
{
    public float x;
    public float y;
};

public class Creator : MonoBehaviour
{
    point p_2 = new point();
    
        // Start is called before the first frame update
    void Start()
    {
        p_2.x = 10;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void create_level(int a, int b, int c, int d) 
    {
        point p_1;
        p_1.x = 10;
    }
}
